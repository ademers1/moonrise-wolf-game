﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    public int Damage;
    public int ID;
    public string type;
    public string description;
    public Sprite icon;
    public bool pickedUp;
}
